﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HMS_Project.Controllers
{
    public class DashboardController : Controller
    {
        // GET: Dashboard
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }
        public ActionResult ManageRooms()
        {
            return View();
        }
        public ActionResult ManageCategories()
        {
            return View();
        }
        public ActionResult ManageUsers()
        {
            return View();
        }
    }
}